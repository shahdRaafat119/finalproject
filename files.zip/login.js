/* ============================================================
   login.js  —  StudyWise login page logic
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {

  /* ── Smart greeting ─────────────────────────────────────────
     First visit  → "Welcome to StudyWise!"
     Return visit → "Welcome back!"
     After typing email → "Hey, [Name]!"
  ── */
  const STORAGE_KEY = 'studywise_visited';

  const titleEl  = document.getElementById('greeting-title');
  const subEl    = document.getElementById('greeting-sub');
  const labelEl  = document.getElementById('greeting-label');

  let hasVisited = false;
  try {
    hasVisited = !!localStorage.getItem(STORAGE_KEY);
  } catch (e) {
    // localStorage not available (private mode, etc.) — treat as first visit
  }

  if (hasVisited) {
    setGreeting('returning');
  } else {
    setGreeting('new');
    try { localStorage.setItem(STORAGE_KEY, '1'); } catch (e) {}
  }

  function setGreeting(type, name = '') {
    titleEl.style.animation = 'none';
    void titleEl.offsetWidth; // reflow to restart animation
    titleEl.style.animation = 'fadeSlideIn 0.45s ease-out';

    if (type === 'named') {
      labelEl.textContent = 'Hey there';
      titleEl.textContent = `Hey, ${name}!`;
      subEl.innerHTML = hasVisited
        ? 'Good to see you again.'
        : 'New here? <a href="#">Create a free account →</a>';

    } else if (type === 'returning') {
      labelEl.textContent = 'Welcome back';
      titleEl.textContent = 'Welcome back!';
      subEl.innerHTML = 'Good to see you again. <a href="#">Create a free account →</a>';

    } else {
      labelEl.textContent = 'First visit';
      titleEl.textContent = 'Welcome to StudyWise!';
      subEl.innerHTML = 'New here? <a href="#">Create a free account →</a>';
    }
  }

  /* Personalise greeting once user types their email */
  const emailInput = document.getElementById('email');
  if (emailInput) {
    emailInput.addEventListener('blur', () => {
      const val = emailInput.value.trim();
      if (val && val.includes('@')) {
        const raw  = val.split('@')[0].replace(/[._\-+]/g, ' ').trim();
        const name = raw.charAt(0).toUpperCase() + raw.slice(1);
        setGreeting('named', name);
      }
    });
  }

  /* ── Form submit ─────────────────────────────────────────── */
  const form = document.getElementById('loginForm');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();

      const email    = document.getElementById('email').value.trim();
      const password = document.getElementById('password').value;

      if (!email || !password) {
        window.showToast('Please fill in all fields.', 'error');
        return;
      }

      /* 
         TODO: Replace the block below with your real API call.
         Example:
           const res = await fetch('/api/auth/login', {
             method: 'POST',
             headers: { 'Content-Type': 'application/json' },
             body: JSON.stringify({ email, password })
           });
           if (res.ok) window.location.href = '/dashboard';
           else window.showToast('Invalid credentials.', 'error');
      */
      console.log('Login attempt:', email);
      window.showToast('Signed in successfully! (demo)', 'success');
      // window.location.href = '/dashboard';
    });
  }

  console.log('✅ Login page ready');
});
