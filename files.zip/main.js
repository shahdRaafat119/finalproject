/* ============================================================
   main.js  —  StudyWise shared utilities
   ============================================================ */

document.addEventListener('DOMContentLoaded', () => {
  console.log('%cStudyWise loaded 🚀', 'color:#a855f7;font-size:15px;font-weight:bold');

  /* ── Toast helper ──────────────────────────────────────────
     Usage: window.showToast('Message here', 'success')
     Types: 'success' | 'error' | 'info'
  ── */
  window.showToast = (message, type = 'success') => {
    const existing = document.querySelector('.sw-toast');
    if (existing) existing.remove();

    const toast = document.createElement('div');
    toast.className = `sw-toast ${type}`;
    toast.textContent = message;
    document.body.appendChild(toast);

    requestAnimationFrame(() => {
      requestAnimationFrame(() => toast.classList.add('show'));
    });

    setTimeout(() => {
      toast.classList.remove('show');
      setTimeout(() => toast.remove(), 300);
    }, 3000);
  };

  console.log('✅ Shared utilities ready');
});
